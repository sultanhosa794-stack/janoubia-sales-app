# Janoubia Sales App

Android wrapper for the Janoubia Sales system.

## Build
GitHub Actions automatically builds an APK after files are pushed to `main`.

Download the generated artifact from:
Actions → latest successful run → Artifacts → Janoubia-Sales-APK


## تحديث الإدارة
- تحديد كل الاعتمادات دفعة واحدة.
- عرض المبيعات مرتبطة باسم الموظف.
- نسخ تقرير اليوم جاهزًا للواتساب: الاسم + غائب/لم يسجل/إجمالي المبيعات + المجموع.
