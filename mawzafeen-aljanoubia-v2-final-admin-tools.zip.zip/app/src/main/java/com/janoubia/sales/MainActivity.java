package com.janoubia.sales;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {

    private static final String APP_URL =
            "https://xhpovyomlqnvuiwihhgm.supabase.co/functions/v1/janoubia-sales";

    private static final long INACTIVITY_TIMEOUT_MS = 5 * 60 * 1000L;

    private WebView webView;
    private ProgressBar progressBar;
    private final Handler inactivityHandler = new Handler(Looper.getMainLooper());
    private long backgroundAt = 0L;
    private boolean pageLoaded = false;

    private SharedPreferences securePrefs;
    private SharedPreferences plainPrefs;

    private final Runnable logoutRunnable = this::forceLogout;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(91, 43, 191));
        initPreferences();

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);

        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 8
        );

        root.addView(webView, webParams);
        root.addView(progressBar, progressParams);
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new AppBridge(), "AndroidSecure");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageLoaded = true;
                injectLoginHooks();
                scheduleLogout();
                maybeOfferSavedLogin();
            }
        });

        loadAppHtml();
    }

    private void initPreferences() {
        plainPrefs = getSharedPreferences("janoubia_plain", MODE_PRIVATE);

        try {
            MasterKey masterKey = new MasterKey.Builder(this)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            securePrefs = EncryptedSharedPreferences.create(
                    this,
                    "janoubia_secure",
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            securePrefs = null;
        }
    }

    private boolean deviceIsSecured() {
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        return km != null && km.isDeviceSecure();
    }

    private void maybeOfferSavedLogin() {
        if (!pageLoaded) return;

        final String username = plainPrefs.getString("saved_username", "");
        if (username == null || username.isEmpty()) return;

        // Always restore username.
        autofillUsername(username);

        // Password is restored only on a secured device and from encrypted storage.
        if (!deviceIsSecured() || securePrefs == null) return;

        final String password = securePrefs.getString("saved_password", "");
        if (password == null || password.isEmpty()) return;

        BiometricManager bm = BiometricManager.from(this);
        int allowed = BiometricManager.Authenticators.BIOMETRIC_STRONG
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL;

        if (bm.canAuthenticate(allowed) != BiometricManager.BIOMETRIC_SUCCESS) return;

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(
                this,
                executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(
                            @NonNull BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        autofillCredentials(username, password);
                    }
                });

        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("فتح بيانات الدخول")
                .setSubtitle("استخدم بصمة الوجه أو الإصبع أو رمز قفل الجهاز")
                .setAllowedAuthenticators(allowed)
                .build();

        prompt.authenticate(info);
    }

    private void autofillUsername(String username) {
        String js = "(function(){var u=document.getElementById('lu');if(u){u.value="
                + jsQuote(username) + ";}})();";
        webView.evaluateJavascript(js, null);
    }

    private void autofillCredentials(String username, String password) {
        String js = "(function(){var u=document.getElementById('lu');var p=document.getElementById('lp');"
                + "if(u)u.value=" + jsQuote(username) + ";"
                + "if(p)p.value=" + jsQuote(password) + ";})();";
        webView.evaluateJavascript(js, null);
    }

    private String jsQuote(String s) {
        if (s == null) return "''";
        return "'" + s.replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\n", "\\n")
                .replace("\r", "\\r") + "'";
    }


    private void injectAdminTools() {
        String js =
                "(function(){"
                + "if(window.__janoubiaAdminToolsPatched)return;"
                + "window.__janoubiaAdminToolsPatched=true;"
                + "function copyText(t){"
                + " if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(function(){if(window.toast)toast('تم نسخ تقرير اليوم');});}"
                + " else{var x=document.createElement('textarea');x.value=t;document.body.appendChild(x);x.select();document.execCommand('copy');x.remove();if(window.toast)toast('تم نسخ تقرير اليوم');}"
                + "}"
                + "function dailyReport(){"
                + " var rows=Array.isArray(window.OVROWS)?window.OVROWS:[];"
                + " var lines=['📋 مبيعات اليوم',''];var total=0;"
                + " rows.forEach(function(r,i){"
                + "   var st=(typeof window.todayState==='function')?window.todayState(r):(!r.todayAttendance?'none':(r.todayAttendance.status==='absent'?'absent':'present'));"
                + "   var val='لم يسجل';"
                + "   if(st==='absent') val='غائب';"
                + "   else if(st==='present'||st==='pending'){val=String((r.todaySales&&r.todaySales.total)||0);total+=Number((r.todaySales&&r.todaySales.total)||0);}"
                + "   lines.push((i+1)+'. '+r.full_name+' — '+val);"
                + " });"
                + " lines.push('');lines.push('المجموع: '+total+' تفعيل');"
                + " return lines.join('\\n');"
                + "}"
                + "function addTools(){"
                + " var box=document.getElementById('ovData');if(!box)return;"
                + " if(!document.getElementById('copyTodayReport')){"
                + "   var bar=document.createElement('div');bar.id='adminQuickTools';bar.className='card';"
                + "   bar.innerHTML='<div style=\"display:grid;grid-template-columns:1fr 1fr;gap:8px\">"
                + "   <button id=\"copyTodayReport\" class=\"btn primary\">📋 نسخ تقرير اليوم</button>"
                + "   <button id=\"selectAllPendingTop\" class=\"btn secondary\">☑️ تحديد كل الاعتمادات</button></div>';"
                + "   box.insertBefore(bar,box.firstChild);"
                + "   document.getElementById('copyTodayReport').onclick=function(){copyText(dailyReport());};"
                + "   document.getElementById('selectAllPendingTop').onclick=function(){"
                + "      var c=document.getElementById('selectAll');if(c){c.checked=true;c.dispatchEvent(new Event('change',{bubbles:true}));if(window.toast)toast('تم تحديد كل الطلبات');}"
                + "      else if(window.toast)toast('افتح الاعتمادات المعلقة أولاً');"
                + "   };"
                + " }"
                + "}"
                + "var oldOverview=window.renderOverviewRows;"
                + "if(typeof oldOverview==='function'){window.renderOverviewRows=function(m){var r=oldOverview(m);setTimeout(addTools,0);return r;};}"
                + "var oldAdmin=window.renderAdmin;"
                + "if(typeof oldAdmin==='function'){window.renderAdmin=async function(){var r=await oldAdmin();setTimeout(addTools,250);return r;};}"
                + "setTimeout(addTools,800);"
                + "})();";
        webView.evaluateJavascript(js, null);
    }

    private void injectLoginHooks() {
        String js =
                "(function(){"
                + "if(window.__janoubiaSecureHook)return;"
                + "window.__janoubiaSecureHook=true;"
                + "var b=document.getElementById('loginBtn');"
                + "if(!b)return;"
                + "b.addEventListener('click',function(){"
                + "setTimeout(function(){"
                + "var u=document.getElementById('lu');"
                + "var p=document.getElementById('lp');"
                + "if(u&&p&&u.value){"
                + "AndroidSecure.saveCredentials(u.value,p.value);"
                + "}"
                + "},700);"
                + "});"
                + "})();";
        webView.evaluateJavascript(js, null);
    }

    private void saveCredentialsNative(String username, String password) {
        plainPrefs.edit().putString("saved_username", username).apply();

        // Never store the password unless the device has a secure lock.
        if (!deviceIsSecured() || securePrefs == null) {
            if (securePrefs != null) securePrefs.edit().remove("saved_password").apply();
            return;
        }

        securePrefs.edit().putString("saved_password", password).apply();
    }

    private void scheduleLogout() {
        inactivityHandler.removeCallbacks(logoutRunnable);
        inactivityHandler.postDelayed(logoutRunnable, INACTIVITY_TIMEOUT_MS);
    }

    private void forceLogout() {
        if (webView == null) return;

        webView.evaluateJavascript(
                "(function(){try{localStorage.removeItem('js_token');localStorage.removeItem('j2t');}catch(e){}location.reload();})();",
                null
        );
        Toast.makeText(
                this,
                "تم تسجيل الخروج تلقائيًا بعد 5 دقائق من عدم الاستخدام",
                Toast.LENGTH_LONG
        ).show();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        scheduleLogout();
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onPause() {
        super.onPause();
        backgroundAt = System.currentTimeMillis();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (backgroundAt > 0 &&
                System.currentTimeMillis() - backgroundAt >= INACTIVITY_TIMEOUT_MS) {
            forceLogout();
        } else {
            scheduleLogout();
        }
        backgroundAt = 0;
    }

    private void loadAppHtml() {
        progressBar.setVisibility(View.VISIBLE);

        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(APP_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(20000);
                connection.setRequestProperty("Accept", "text/html,*/*");
                connection.setRequestProperty("User-Agent", "JanoubiaSalesAndroid/1.1");
                connection.setInstanceFollowRedirects(true);

                int status = connection.getResponseCode();
                InputStream stream = (status >= 200 && status < 400)
                        ? connection.getInputStream()
                        : connection.getErrorStream();

                if (stream == null) throw new Exception("Empty response");

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(stream, StandardCharsets.UTF_8)
                );

                StringBuilder html = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    html.append(line).append('\n');
                }
                reader.close();

                final String page = html.toString();

                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    webView.loadDataWithBaseURL(
                            APP_URL,
                            page,
                            "text/html",
                            "UTF-8",
                            APP_URL
                    );
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(
                            MainActivity.this,
                            "تعذر تحميل التطبيق. تحقق من الإنترنت ثم أعد المحاولة.",
                            Toast.LENGTH_LONG
                    ).show();
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }

    public class AppBridge {
        @JavascriptInterface
        public void saveCredentials(String username, String password) {
            runOnUiThread(() -> saveCredentialsNative(username, password));
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
