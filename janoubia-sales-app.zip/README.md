# Janoubia Sales App

Android wrapper for the Janoubia Sales system.

## Build
GitHub Actions automatically builds an APK after files are pushed to `main`.

Download the generated artifact from:
Actions → latest successful run → Artifacts → Janoubia-Sales-APK
